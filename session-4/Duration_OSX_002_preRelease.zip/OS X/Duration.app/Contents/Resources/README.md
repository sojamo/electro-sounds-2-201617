ofxLocalization
===============

A simple CSV parser and lookup table for easy localization.

Works great with ofxFTGL (https://github.com/Flightphase/ofxFTGL) for translating to Unicode based characters (Chinese/Japanese, etc)

Made at YCAM InterLab (http://interlab.ycam.jp)